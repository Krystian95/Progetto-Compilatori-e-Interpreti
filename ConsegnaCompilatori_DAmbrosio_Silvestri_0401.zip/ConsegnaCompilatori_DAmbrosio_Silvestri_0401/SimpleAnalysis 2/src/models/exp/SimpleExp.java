package models.exp;

import models.SimpleElementBase;

public abstract class SimpleExp extends SimpleElementBase {
	
}
