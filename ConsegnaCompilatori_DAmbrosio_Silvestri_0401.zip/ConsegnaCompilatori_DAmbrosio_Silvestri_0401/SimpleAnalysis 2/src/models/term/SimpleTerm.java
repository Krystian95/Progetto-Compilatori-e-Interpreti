package models.term;

import models.exp.SimpleExp;

public abstract class SimpleTerm extends SimpleExp {

}
