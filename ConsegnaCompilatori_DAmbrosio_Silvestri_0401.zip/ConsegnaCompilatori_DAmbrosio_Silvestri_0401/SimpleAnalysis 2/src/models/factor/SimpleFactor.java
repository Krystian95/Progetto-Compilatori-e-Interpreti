package models.factor;

import models.term.SimpleTerm;

public abstract class SimpleFactor extends SimpleTerm {		
	
}
