package models.type;

import models.SimpleElementBase;

public abstract class SimpleType extends SimpleElementBase {

}
