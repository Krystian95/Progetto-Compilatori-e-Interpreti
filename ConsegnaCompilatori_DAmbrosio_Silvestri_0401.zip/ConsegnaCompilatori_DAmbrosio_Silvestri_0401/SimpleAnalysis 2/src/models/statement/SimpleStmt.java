package models.statement;

import models.SimpleElementBase;

public abstract class SimpleStmt extends SimpleElementBase {
	
}
