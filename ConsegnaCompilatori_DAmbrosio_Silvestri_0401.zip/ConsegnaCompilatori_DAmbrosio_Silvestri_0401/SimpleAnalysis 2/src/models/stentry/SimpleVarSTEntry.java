package models.stentry;

import models.type.SimpleType;

public class SimpleVarSTEntry extends SimpleSTEntry {

	public SimpleVarSTEntry(int nestingLevel, SimpleType type, int offset, String id) {
		super(nestingLevel, type, offset, id);
	}

}
