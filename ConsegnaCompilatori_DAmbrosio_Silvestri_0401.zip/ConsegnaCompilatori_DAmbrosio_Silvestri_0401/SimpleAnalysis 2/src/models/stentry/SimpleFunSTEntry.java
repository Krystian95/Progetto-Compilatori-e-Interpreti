package models.stentry;

import models.type.SimpleType;

public class SimpleFunSTEntry extends SimpleSTEntry {

	public SimpleFunSTEntry(int n, SimpleType t, int os, String id) {
		super(n, t, os, id);
	}

}
