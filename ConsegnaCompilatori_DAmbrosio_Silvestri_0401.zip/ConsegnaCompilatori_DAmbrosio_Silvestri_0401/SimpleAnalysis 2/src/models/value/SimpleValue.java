package models.value;

import models.factor.SimpleFactor;

public abstract class SimpleValue extends SimpleFactor {
	
}
