Progetto di Compilatori e interpreti

Passo 1) scaricare il progetto dal link contenuto nell'email;
Passo 2) Aprire Eclipse;
Passo 3) Importare il progetto scaricato dal nome "SimpleAnalysis 2";
Passo 4) Includere la libreria Antlr 4.6 e fare "build";
Passo 5) Inserire uno degli esempi presenti nel file "serbatoio" in "test.spl", oppure scrivere un esempio in quest'ultimo file.
Passo 6) Eseguire il file "Analyse.java"

Consegnato il 04/01/2020 da:
-D'Ambrosio Luca 0000890761
-Silvestri Marco 0000889874